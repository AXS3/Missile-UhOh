
var time = 300;
const bombBoomEffect = newEffect(20, e => {
    Draw.color(Color.orange, Color.red, e.fin()); 
    Lines.stroke(e.fout() * 3); 
    Lines.circle(e.x, e.y, e.fin() * 30); 
});
const bomb = extendContent(Block, "bomb", {
update(tile){
//timer
	if ( time > 300) {
	time--;
	}
	else {
	
	Effects.effect(bombBoomEffect, tile);
	for ( var i = 10; i > 1; i--){
	time = 500;
	//call healt bullet 
	Calls.createBullet(Bullets.standardThoriumBig, tile.getTeam(), tile.drawx(), tile.drawy(), Mathf.random(360), Mathf.random(0.5, 1.0), Mathf.random(0.2, 1.0));
	}
	//destroy block
	tile.entity.health -= 999;
	};
	
	},
 
})

