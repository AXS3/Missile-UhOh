            //Топливный генератор
const fuelGenerator = extendContent( SingleTypeGenerator, "fuelGenerator", {
getLiquidEfficiency(liquid){
return 1;
}
});
            //Лавовый термальный генератор 
const lavaGenerator = extendContent( SingleTypeGenerator, "lavaGenerator", {
getLiquidEfficiency(liquid){
return 1;
}
});