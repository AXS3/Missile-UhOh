if (typeof(cons2)== "undefined"){
const cons2 = method => new Cons2(){get : method};
}
const mtesla=extendContent(ChargeTurret,"mini-tesla",{
  bullet(tile,type,angle){
    Bullet.create(type,tile.entity,tile.getTeam(),tile.drawx(),tile.drawy(),angle);
  },
  drawLayer(tile){
    const entity=tile.ent();
    Draw.rect(this.region,tile.drawx(),tile.drawy(),0);
    if(this.heatRegion!=Core.atlas.find("error")){
      this.heatDrawer.get(tile,entity);
    }
  }
});
mtesla.shootType=extend(BasicBulletType,{
  draw(b){},
  init(b){
    if(b==null) return;
    Lightning.create(b.getTeam(),Pal.lancerLaser,this.damage,b.x,b.y,b.rot(),30+Mathf.round(Mathf.random()*20));
  }
});
mtesla.shootType.lifetime=1
mtesla.shootType.speed=0.001
mtesla.shootType.hitEffect=Fx.hitLancer;
mtesla.shootType.damage=32;
mtesla.heatColor=Color.red;
